function grow() {
    document.getElementById("box").style.height= "250px";
}

function color() {
    document.getElementById("box").style.backgroundColor= "#0000ff";
}

function fade() {
    document.getElementById("box").style.opacity="0.5";
}

function reset() {
    document.getElementById("box").style.height="150px";
    document.getElementById("box").style.backgroundColor="orange";
    document.getElementById("box").style.opacity="1";
}